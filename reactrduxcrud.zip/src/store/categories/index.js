import * as categoriesActions from './actions';
import * as categoriesSelectors from './selectors';

export {
  categoriesActions,
  categoriesSelectors,
};
