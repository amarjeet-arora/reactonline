


export default function() {

    return [
        {title: 'Angular book',author: 'auth1', price:101},
        {title: 'react book',author: 'auth1', price:101},
        {title: 'Mongo book',author: 'auth1', price:101}
    ]
}