import React,{ Component } from "react";
import  {connect} from 'react-redux'
 import {selectBook} from '../actions/index'
 import {bindActionCreators} from 'redux'
class BookList extends Component{
renderList() {
    return this.props.bk.map((book) =>{
        return (
            <li 
            key={book.title}>
                onClick={() => this.props.sb(book)}
            {book.title} </li>
        )
    })
}

    render(){
        return (
            <div>
            <h3>welcome to bookList</h3>
            {this.renderList()}
            </div>
        )
    }
}

function mapStateToProps(state) {

    return {
        bk : state.books
    }
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({sb:selectBook},dispatch)
}
export default connect(mapStateToProps,mapDispatchToProps)(BookList)