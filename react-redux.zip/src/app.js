import React, { Component } from "react";
import ReactDOM from 'react-dom'
import BookStore from "./components/BookStore";
import {Provider} from 'react-redux'
 import reducers from './reducers'
import {createStore} from 'redux'

ReactDOM.render(
    <Provider store ={createStore(reducers)}>
<BookStore/>
</Provider>
, document.getElementById("root"))