import React,{ Component } from "react"
import Header from "./header"
import Footer from "./footer"
import Options from "./options"
import Action from "./action"
import AddOption from "./addoption"

export default class MyComp extends Component {

    render(){
        const options =['data1','data2','data3']
        return (
<div>
    <Header data1="this data for header from Mycomp"/>
    <p>welcome to my child component</p>
    <Options optiondata={options}/>

    <Action/>
    <AddOption/>
<Footer/>
</div>

        )
    }

}