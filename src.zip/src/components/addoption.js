import React,{ Component } from "react"

export default class AddOption extends Component {

    callme(e){
    e.preventDefault()
        
        const data= e.target.elements.uname.value
        alert(data)
    }
    render(){
        return (
<div>
     <form onSubmit={this.callme}> 
     Name<input type="text" name="uname"/>
         <button>add</button>
     </form>
</div>

        )
    }

}