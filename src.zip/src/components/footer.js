import React,{ Component } from "react"

export default class Footer extends Component {

    render(){
        return (
<div>
    <p>welcome to footer</p>
</div>

        )
    }

}