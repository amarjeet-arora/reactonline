import React,{ Component } from "react"

export default class Action extends Component {
callme(){
    alert('welcome to callme')
}

    render(){
        return (
<div>
     <button onClick={this.callme}>call me</button>
</div>

        )
    }

}