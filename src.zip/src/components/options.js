import React,{ Component } from "react"
import Option from "./option"

export default class Options extends Component {

    render(){
        return (
<div>
    {
  this.props.optiondata.map((data) => <Option optionText={data} />)
    }
</div>

        )
    }

}