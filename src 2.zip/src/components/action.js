import React,{ Component } from "react"

export default class Action extends Component {
callme(){
    alert('welcome to callme')
}

    render(){
        return (
<div>
     <button disabled={!this.props.hasOption} onClick={this.callme}>call me</button>
</div>

        )
    }

}