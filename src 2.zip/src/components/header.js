import React,{ Component } from "react"

export default class Header extends Component {

    render(){
        return (
<div>
    <p>welcome to my header component</p>
    {this.props.data1}
</div>

        )
    }

}