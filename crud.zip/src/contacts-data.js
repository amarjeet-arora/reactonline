export const contacts = [
  {
    _id: "1",
    name: {
      first:"John",
      last:"Doe"
    },
    phone:"555",
    email:"john@gmail.com"
  },
  {
    _id: "2",
    name: {
      first:"Bruce",
      last:"Wayne"
    },
    phone:"777",
    email:"bruce.wayne@gmail.com"
  }
];
