import React, { Component } from 'react';
import PropTypes from 'prop-types';

export default class LoadingIndicator extends Component {
  static propTypes = {
    isLoading: PropTypes.bool.isRequired,
  };
  /* Requirements
  Our component is going to take a single boolean prop: isLoading.
  
  When isLoading is false, we will render the component’s children.
  
  When isLoading is true…
  
  If 200ms have elapsed, we will display text to indicate that we are “loading”.
  If 200ms have not yet elapsed, we will display nothing. */
  state = {
    isPastDelay: false
  };

  componentDidMount () {
    this._delayTimer = setTimeout(
      () => this.setState({ isPastDelay: true }), 200
    );
  }

  componentWillUnmount() {
    clearTimeout(this._delayTimer);
  }

  render() {
    if (this.props.isLoading) {
      if (!this.state.isPastDelay) {
        return null;
      }
      return <div>loading...</div>;
    }
    return this.props.children;
  }
}
